# ============================================================================
# bytetrack_tracker.py
# ============================================================================

from __future__ import annotations

import numpy as np

from core.config import Config
from core.schemas import Detection
from core.schemas import Track

from tracking.base_tracker import BaseTracker


class ByteTrackTracker(BaseTracker):
    """
    Wrapper for ByteTrack algorithm.
    """

    def __init__(
        self,
        config: Config,
    ) -> None:

        tracking_cfg = config["tracking"]["bytetrack"]

        self.cfg = tracking_cfg

        self._active_tracks: list[Track] = []

        # TODO
        # Initialize ByteTrack

    @property
    def active_tracks(
        self,
    ) -> list[Track]:

        return self._active_tracks

    def update(
        self,
        detections: list[Detection],
        frame: np.ndarray | None = None,
    ) -> list[Track]:

        # TODO
        # Convert Detection → ByteTrack input
        # Run tracker
        # Convert results → Track

        return []

    def reset(
        self,
    ) -> None:

        self._active_tracks.clear()