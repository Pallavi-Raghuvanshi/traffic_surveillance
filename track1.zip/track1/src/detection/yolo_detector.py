# ============================================================================
# yolo_detector.py
# ============================================================================

from __future__ import annotations

import numpy as np

from core.config import Config
from core.schemas import Detection

from detection.base_detector import BaseDetector


class YOLODetector(BaseDetector):
    """
    Wrapper for all YOLO models.

    Supported models
    ----------------
    YOLO11
    YOLO26
    YOLOv8
    Future YOLO releases
    """

    def __init__(
        self,
        config: Config,
    ) -> None:

        detection_cfg = config["detection"]

        self.model_name = detection_cfg["model"]

        self.confidence = detection_cfg["confidence"]

        self.iou = detection_cfg["iou"]

        self.device = detection_cfg["device"]

        # TODO:
        #
        # self.model = YOLO(self.model_name)

    def detect(
        self,
        frame: np.ndarray,
    ) -> list[Detection]:

        # TODO
        #
        # Run inference
        #
        # Convert results to Detection objects

        return []

    def reset(self) -> None:

        pass